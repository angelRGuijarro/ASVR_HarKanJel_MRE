# mre-altspacevr-extras package

This package contains a number of AltspaceVR specific APIs to be used together with the Mixed Reality Extension SDK

