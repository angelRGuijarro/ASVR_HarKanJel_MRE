module.exports = {
	"rules": {
		"max-len": "off",
		"curly": "off",
		"no-var": "off",
		"@typescript-eslint/prefer-string-starts-ends-with": "off",
		"default-param-last": "off",
		"@typescript-eslint/interface-name-prefix": "off",
		"@typescript-eslint/unbound-method": "off",
		"@typescript-eslint/camelcase": "off",
		"@typescript-eslint/member-delimiter-style": "off",
		"@typescript-eslint/no-unnecessary-type-assertion": "off"
	}
}
