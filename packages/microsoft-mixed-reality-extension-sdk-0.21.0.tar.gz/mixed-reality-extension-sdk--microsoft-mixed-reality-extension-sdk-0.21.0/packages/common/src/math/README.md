# References

These math classes are based on those of Babylon.js (copied from version 4.0.0-alpha.5).
