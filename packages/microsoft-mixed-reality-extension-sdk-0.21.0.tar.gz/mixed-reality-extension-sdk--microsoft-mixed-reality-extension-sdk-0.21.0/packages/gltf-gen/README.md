# glTF Generator

Generate glTF buffers (for writing or streaming) on the fly from vertex data.

[Documentation](https://microsoft.github.io/mixed-reality-extension-sdk/gltf-gen)
